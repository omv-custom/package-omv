# -*- coding: utf-8 -*-
'''
salt.proxy package
'''
