salt.executors.direct_call
==========================

.. automodule:: salt.executors.direct_call
    :members:
