salt.executors.sudo
===================

.. automodule:: salt.executors.sudo
    :members:
