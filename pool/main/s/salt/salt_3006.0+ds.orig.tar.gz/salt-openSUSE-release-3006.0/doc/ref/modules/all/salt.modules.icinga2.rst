salt.modules.icinga2
====================

.. automodule:: salt.modules.icinga2
    :members:
    :undoc-members:
