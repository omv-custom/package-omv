salt.modules.ethtool
====================

.. automodule:: salt.modules.ethtool
    :members:
