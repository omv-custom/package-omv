=====================
salt.modules.cisconso
=====================

.. automodule:: salt.modules.cisconso
    :members:
