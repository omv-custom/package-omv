salt.modules.ceph
=================

.. automodule:: salt.modules.ceph
    :members:
    :undoc-members:
