salt.modules.jira_mod
=====================

.. automodule:: salt.modules.jira_mod
    :members:
