salt.modules.cimc
=================

.. automodule:: salt.modules.cimc
    :members:
