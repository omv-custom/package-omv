salt.modules.celery
===================

.. automodule:: salt.modules.celery
    :members:
    :undoc-members:
