salt.modules.jenkinsmod
=======================

.. automodule:: salt.modules.jenkinsmod
    :members:
