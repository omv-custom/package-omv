salt.grains.metadata_gce
========================

.. automodule:: salt.grains.metadata_gce
    :members:
