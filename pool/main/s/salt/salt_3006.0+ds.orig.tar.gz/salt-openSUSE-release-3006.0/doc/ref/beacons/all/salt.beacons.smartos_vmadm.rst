salt.beacons.smartos_vmadm
==========================

.. automodule:: salt.beacons.smartos_vmadm
    :members:
