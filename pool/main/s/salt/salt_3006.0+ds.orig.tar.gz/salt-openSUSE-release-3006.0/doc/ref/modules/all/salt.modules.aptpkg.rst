salt.modules.aptpkg
===================

.. automodule:: salt.modules.aptpkg
    :members:
    :exclude-members: available_version
