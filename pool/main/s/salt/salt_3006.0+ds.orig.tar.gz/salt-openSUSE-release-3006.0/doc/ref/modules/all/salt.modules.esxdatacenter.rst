salt.modules.esxdatacenter
==========================

.. automodule:: salt.modules.esxdatacenter
    :members:
    :undoc-members:
