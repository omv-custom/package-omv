salt.modules.freezer
====================

.. automodule:: salt.modules.freezer
    :members:
    :undoc-members:
