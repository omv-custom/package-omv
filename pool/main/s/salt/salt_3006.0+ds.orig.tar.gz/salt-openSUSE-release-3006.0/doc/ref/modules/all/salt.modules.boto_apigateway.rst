salt.modules.boto_apigateway
============================

.. automodule:: salt.modules.boto_apigateway
    :members:
