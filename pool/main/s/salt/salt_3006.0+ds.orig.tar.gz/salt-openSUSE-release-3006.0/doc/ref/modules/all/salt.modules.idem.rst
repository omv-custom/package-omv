salt.modules.idem
=================

.. automodule:: salt.modules.idem
    :members:
