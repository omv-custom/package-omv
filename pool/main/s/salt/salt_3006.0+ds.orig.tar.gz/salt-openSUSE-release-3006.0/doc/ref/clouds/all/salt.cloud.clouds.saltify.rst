salt.cloud.clouds.saltify
=========================

.. automodule:: salt.cloud.clouds.saltify
    :members:
