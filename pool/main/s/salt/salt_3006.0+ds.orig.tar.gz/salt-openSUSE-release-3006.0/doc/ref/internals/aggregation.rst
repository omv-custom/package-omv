================
salt.aggregation
================

.. automodule:: salt.utils.aggregation
    :members:
    :noindex: salt.utils.odict.OrderedDict
