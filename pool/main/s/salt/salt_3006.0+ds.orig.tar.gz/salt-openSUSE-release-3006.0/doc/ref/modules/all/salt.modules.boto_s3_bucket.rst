salt.modules.boto_s3_bucket
===========================

.. automodule:: salt.modules.boto_s3_bucket
    :members:
