salt.cloud.clouds.opennebula
============================

.. automodule:: salt.cloud.clouds.opennebula
    :members:
