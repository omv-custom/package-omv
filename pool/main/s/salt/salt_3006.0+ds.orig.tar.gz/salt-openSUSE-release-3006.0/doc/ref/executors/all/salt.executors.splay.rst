salt.executors.splay
====================

.. automodule:: salt.executors.splay
    :members:
