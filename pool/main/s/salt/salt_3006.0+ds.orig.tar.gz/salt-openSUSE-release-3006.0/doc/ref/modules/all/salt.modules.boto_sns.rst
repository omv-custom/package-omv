salt.modules.boto_sns
=====================

.. automodule:: salt.modules.boto_sns
    :members:
