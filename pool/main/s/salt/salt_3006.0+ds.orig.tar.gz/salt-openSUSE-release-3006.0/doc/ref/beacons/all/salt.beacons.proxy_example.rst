salt.beacons.proxy_example
==========================

.. automodule:: salt.beacons.proxy_example
    :members:
