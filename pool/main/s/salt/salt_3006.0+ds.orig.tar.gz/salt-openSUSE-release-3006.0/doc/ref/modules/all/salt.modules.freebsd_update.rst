salt.modules.freebsd_update
===========================

.. automodule:: salt.modules.freebsd_update
    :members:
    :undoc-members:
