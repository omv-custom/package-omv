salt.modules.boto_cognitoidentity
=================================

.. automodule:: salt.modules.boto_cognitoidentity
    :members:
