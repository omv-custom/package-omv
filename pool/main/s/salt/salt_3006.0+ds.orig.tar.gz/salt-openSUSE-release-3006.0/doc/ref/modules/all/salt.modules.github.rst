salt.modules.github
===================

.. automodule:: salt.modules.github
    :members:
