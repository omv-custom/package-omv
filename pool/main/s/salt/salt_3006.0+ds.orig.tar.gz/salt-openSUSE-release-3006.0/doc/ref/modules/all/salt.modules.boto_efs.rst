salt.modules.boto_efs
=====================

.. automodule:: salt.modules.boto_efs
    :members:
    :undoc-members:
