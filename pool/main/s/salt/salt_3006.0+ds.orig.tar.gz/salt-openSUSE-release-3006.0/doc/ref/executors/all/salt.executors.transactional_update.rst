salt.executors.transactional_update module
==========================================

.. automodule:: salt.executors.transactional_update
    :members:
