salt.beacons.salt_proxy
=======================

.. automodule:: salt.beacons.salt_proxy
    :members:
