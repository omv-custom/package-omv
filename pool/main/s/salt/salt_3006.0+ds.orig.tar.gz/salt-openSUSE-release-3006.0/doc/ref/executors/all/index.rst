.. _all-salt.executors:

=================
executors modules
=================

.. currentmodule:: salt.executors

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    direct_call
    docker
    splay
    sudo
    transactional_update
