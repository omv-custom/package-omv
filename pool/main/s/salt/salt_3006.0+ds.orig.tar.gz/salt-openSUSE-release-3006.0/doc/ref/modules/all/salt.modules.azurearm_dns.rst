salt.modules.azurearm_dns
=========================

.. automodule:: salt.modules.azurearm_dns
    :members:
    :undoc-members:
