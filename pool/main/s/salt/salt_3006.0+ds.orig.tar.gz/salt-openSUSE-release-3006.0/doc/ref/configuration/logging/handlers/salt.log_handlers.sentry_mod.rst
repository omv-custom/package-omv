============================
salt.log_handlers.sentry_mod
============================

.. automodule:: salt.log_handlers.sentry_mod
