salt.beacons.status
===================

.. automodule:: salt.beacons.status
    :members:
    :undoc-members:
