==============================
salt.log_handlers.logstash_mod
==============================

.. automodule:: salt.log_handlers.logstash_mod
