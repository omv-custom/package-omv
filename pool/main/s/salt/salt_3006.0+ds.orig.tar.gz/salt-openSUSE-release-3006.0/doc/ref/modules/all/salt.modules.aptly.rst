salt.modules.aptly
==================

.. automodule:: salt.modules.aptly
    :members:
    :undoc-members:
