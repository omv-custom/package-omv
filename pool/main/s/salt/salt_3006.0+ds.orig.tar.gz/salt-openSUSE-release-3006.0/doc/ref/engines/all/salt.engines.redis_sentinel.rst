salt.engines.redis_sentinel
===========================

.. automodule:: salt.engines.redis_sentinel
    :members:
