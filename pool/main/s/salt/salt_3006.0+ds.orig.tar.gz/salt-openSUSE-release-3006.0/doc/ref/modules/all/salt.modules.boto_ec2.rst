salt.modules.boto_ec2
=====================

.. automodule:: salt.modules.boto_ec2
    :members:
