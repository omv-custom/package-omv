salt.modules.ciscoconfparse_mod
===============================

.. automodule:: salt.modules.ciscoconfparse_mod
    :members:
