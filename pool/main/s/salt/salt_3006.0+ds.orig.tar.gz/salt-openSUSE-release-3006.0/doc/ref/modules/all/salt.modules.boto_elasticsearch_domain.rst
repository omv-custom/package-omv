salt.modules.boto_elasticsearch_domain
======================================

.. automodule:: salt.modules.boto_elasticsearch_domain
    :members:
