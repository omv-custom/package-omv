salt.modules.boto3_elasticache
==============================

.. automodule:: salt.modules.boto3_elasticache
    :members:
    :undoc-members:
