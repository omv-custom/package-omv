salt.beacons.swapusage
======================

.. automodule:: salt.beacons.swapusage
    :members:
