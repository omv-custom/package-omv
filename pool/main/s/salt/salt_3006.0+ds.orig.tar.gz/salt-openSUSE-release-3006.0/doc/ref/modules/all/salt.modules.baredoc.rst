salt.modules.baredoc
====================

.. automodule:: salt.modules.baredoc
    :members:
