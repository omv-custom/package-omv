salt.modules.boto_lambda
========================

.. automodule:: salt.modules.boto_lambda
    :members:
