salt.beacons.diskusage
======================

.. automodule:: salt.beacons.diskusage
    :members:
