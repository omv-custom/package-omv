salt.modules.gem
================

.. automodule:: salt.modules.gem
    :members:
