salt.modules.hadoop
===================

.. automodule:: salt.modules.hadoop
    :members:
