salt.modules.inspectlib.collector
=================================

.. automodule:: salt.modules.inspectlib.collector
    :members:
