salt.modules.boto3_elasticsearch
================================

.. automodule:: salt.modules.boto3_elasticsearch
    :members:
