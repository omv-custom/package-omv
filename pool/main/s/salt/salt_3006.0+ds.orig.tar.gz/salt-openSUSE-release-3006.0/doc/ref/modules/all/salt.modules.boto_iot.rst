salt.modules.boto_iot
=====================

.. automodule:: salt.modules.boto_iot
    :members:
