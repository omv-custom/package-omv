salt.modules.boto_datapipeline
==============================

.. automodule:: salt.modules.boto_datapipeline
    :members:
