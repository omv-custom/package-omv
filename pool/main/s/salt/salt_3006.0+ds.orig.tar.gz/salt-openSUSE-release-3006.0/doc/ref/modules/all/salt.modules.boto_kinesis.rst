salt.modules.boto_kinesis
=========================

.. automodule:: salt.modules.boto_kinesis
    :members:
    :undoc-members:
