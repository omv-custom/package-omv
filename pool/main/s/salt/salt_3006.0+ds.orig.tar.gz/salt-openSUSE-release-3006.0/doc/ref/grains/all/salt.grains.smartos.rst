salt.grains.smartos
===================

.. automodule:: salt.grains.smartos
    :members:
