salt.modules.boto_ssm
=====================

.. automodule:: salt.modules.boto_ssm
    :members:
    :undoc-members:
