salt.modules.inspectlib.entities
================================

.. automodule:: salt.modules.inspectlib.entities
    :members:
    :undoc-members:
