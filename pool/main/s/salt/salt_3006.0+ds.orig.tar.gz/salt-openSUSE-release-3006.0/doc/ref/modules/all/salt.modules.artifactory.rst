salt.modules.artifactory
========================

.. automodule:: salt.modules.artifactory
    :members:
