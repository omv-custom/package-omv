salt.modules.boto_cloudtrail
============================

.. automodule:: salt.modules.boto_cloudtrail
    :members:
