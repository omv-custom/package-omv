salt.grains.metadata_azure
==========================

.. automodule:: salt.grains.metadata_azure
    :members:
