===============================
salt.log_handlers.log4mongo_mod
===============================

.. automodule:: salt.log_handlers.log4mongo_mod
