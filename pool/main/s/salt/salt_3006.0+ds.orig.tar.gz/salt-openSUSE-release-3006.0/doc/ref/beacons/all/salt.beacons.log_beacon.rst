salt.beacons.log_beacon
=======================

.. automodule:: salt.beacons.log_beacon
    :members:
    :undoc-members:
