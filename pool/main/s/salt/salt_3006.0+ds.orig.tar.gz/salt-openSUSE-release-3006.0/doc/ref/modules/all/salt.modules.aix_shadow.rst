salt.modules.aix_shadow
=======================

.. automodule:: salt.modules.aix_shadow
    :members:
    :undoc-members:
