salt.modules.freebsdservice
===========================

.. automodule:: salt.modules.freebsdservice
    :members:
