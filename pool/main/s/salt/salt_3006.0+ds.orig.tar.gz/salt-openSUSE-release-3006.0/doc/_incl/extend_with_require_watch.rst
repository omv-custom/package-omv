.. admonition:: Using extend with require or watch

    The ``extend`` statement works differently for ``require`` or ``watch``.
    It appends to, rather than replacing the requisite component.
