**Before continuing** make sure you have a working Salt installation by
following the instructions in the
`Salt install guide <https://docs.saltproject.io/salt/install-guide/en/latest/>`_.

.. admonition:: Stuck?

    The Salt Project community can help offer advice and help troubleshoot
    technical issues as you're learning about Salt. One of the best places to
    talk to the community is on the
    `Salt Project Slack workspace <https://saltstackcommunity.slack.com/>`_.
