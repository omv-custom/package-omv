salt.beacons.avahi_announce
===========================

.. automodule:: salt.beacons.avahi_announce
    :members:
    :undoc-members:
