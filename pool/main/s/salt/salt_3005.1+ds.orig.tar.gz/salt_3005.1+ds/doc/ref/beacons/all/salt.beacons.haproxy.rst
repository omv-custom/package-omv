salt.beacons.haproxy
====================

.. automodule:: salt.beacons.haproxy
    :members:
    :undoc-members:
