salt.engines.libvirt_events
===========================

.. automodule:: salt.engines.libvirt_events
    :members:
    :undoc-members:
