salt.sdb.couchdb
================

.. automodule:: salt.sdb.couchdb
    :members: