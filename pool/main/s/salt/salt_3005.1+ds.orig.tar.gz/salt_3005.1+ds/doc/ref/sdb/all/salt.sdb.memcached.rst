salt.sdb.memcached
==================

.. automodule:: salt.sdb.memcached
    :members: