salt.engines.slack
==================

.. automodule:: salt.engines.slack
    :members:
