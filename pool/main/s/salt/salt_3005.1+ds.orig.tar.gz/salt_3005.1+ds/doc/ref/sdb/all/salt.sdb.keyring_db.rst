salt.sdb.keyring_db
===================

.. automodule:: salt.sdb.keyring_db
    :members: