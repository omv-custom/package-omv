salt.sdb.rest
=============

.. automodule:: salt.sdb.rest
    :members:
