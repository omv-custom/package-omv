=========================
salt.beacons.salt_monitor
=========================

.. automodule:: salt.beacons.salt_monitor
    :members: