salt.sdb.confidant
==================

.. automodule:: salt.sdb.confidant
    :members: