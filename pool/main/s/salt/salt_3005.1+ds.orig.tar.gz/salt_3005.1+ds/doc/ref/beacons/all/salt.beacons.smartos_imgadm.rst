salt.beacons.smartos_imgadm
===========================

.. automodule:: salt.beacons.smartos_imgadm
    :members:
