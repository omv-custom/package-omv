.. _all-salt.sdb:

===========
sdb modules
===========

.. currentmodule:: salt.sdb

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    cache
    confidant
    consul
    couchdb
    env
    etcd_db
    keyring_db
    memcached
    redis_sdb
    rest
    sqlite3
    tism
    vault
    yaml

