salt.beacons.napalm_beacon
==========================

.. automodule:: salt.beacons.napalm_beacon
    :members:
