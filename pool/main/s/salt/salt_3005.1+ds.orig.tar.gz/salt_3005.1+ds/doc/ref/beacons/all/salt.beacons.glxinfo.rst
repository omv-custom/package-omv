salt.beacons.glxinfo
====================

.. automodule:: salt.beacons.glxinfo
    :members:
