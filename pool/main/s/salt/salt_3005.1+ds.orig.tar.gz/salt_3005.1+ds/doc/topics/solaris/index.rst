=======
Solaris
=======

This section contains details on Solaris specific quirks and workarounds.

.. note::
   Solaris refers to both Solaris 10 compatible platforms like Solaris 10, illumos, SmartOS, OmniOS, OpenIndiana,... and Oracle Solaris 11 platforms.

.. toctree::
    :glob:

    *
