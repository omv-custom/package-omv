==============================
Getting Started with Openstack
==============================

See :mod:`salt.cloud.clouds.openstack`
