=======
Windows
=======

This section contains details on the Windows Package Manager, and specific information you need
to use Salt on Windows.

.. toctree::
    :glob:

    *