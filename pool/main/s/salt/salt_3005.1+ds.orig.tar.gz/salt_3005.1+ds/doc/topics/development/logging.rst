.. _logging-internals:

=================
Logging Internals
=================

TODO
