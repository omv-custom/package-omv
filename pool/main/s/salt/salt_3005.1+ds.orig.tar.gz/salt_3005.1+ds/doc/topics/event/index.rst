.. index:: ! Event, event bus, event system
    see: Reactor; Event

.. _events:

================
Events & Reactor
================



.. toctree::

    events
    ../beacons/index
    ../reactor/index