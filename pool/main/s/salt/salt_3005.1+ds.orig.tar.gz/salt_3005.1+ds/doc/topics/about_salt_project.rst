.. _about-salt-project:

============
Salt Project
============

.. include:: ../../README.rst