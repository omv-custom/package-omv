:orphan:

.. _legacy-salt-cloud-release-notes:

===============================
Legacy salt-cloud Release Notes
===============================

.. versionchanged:: 2014.1.0

    As of Salt's 2014.1.0 release salt-cloud is part of mainline
    Salt. Future salt-cloud release notes will be included in Salt's regular
    release notes.

.. releasestree::
    :maxdepth: 1
    :glob:

    *
