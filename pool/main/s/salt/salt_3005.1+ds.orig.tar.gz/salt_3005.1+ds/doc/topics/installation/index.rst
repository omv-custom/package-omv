.. _installation:

============
Installation
============

See the `Salt Install Guide <https://docs.saltproject.io/salt/install-guide/en/latest/>`_
for the current installation instructions.
