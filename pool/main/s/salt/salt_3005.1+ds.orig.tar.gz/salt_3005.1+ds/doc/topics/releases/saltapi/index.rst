:orphan:

.. _legacy-salt-api-release-notes:

=============
Release notes
=============

.. releasestree::
    :maxdepth: 1
    :glob:

    *