#!/bin/bash
exec /opt/salt/bin/salt-minion $@