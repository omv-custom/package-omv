ShaSums
=======

This directory contains shasums for files that are downloaded by the `build_env.sh` script.

The sha's have been created using the following command:


```
shasum -a 512 ./<filename> > ./<filename>.sha512
```
