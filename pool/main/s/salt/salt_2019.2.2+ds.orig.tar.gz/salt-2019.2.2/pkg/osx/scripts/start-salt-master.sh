#!/bin/bash
exec /opt/salt/bin/salt-master $@