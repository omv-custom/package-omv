========================
Support for Alpine Linux
========================

This directory contains initialization scripts for Salt services which intended
to be used during the bootstrap process on Alpine Linux (OpenRC init system).
