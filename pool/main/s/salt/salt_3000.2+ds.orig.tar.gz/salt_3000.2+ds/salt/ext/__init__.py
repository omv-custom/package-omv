# coding: utf-8 -*-
'''
This directory contains external modules shipping with Salt. They are governed
under their respective licenses. See the COPYING file included with this
distribution for more information.
'''
